function submitEntry() {
  const name = document.getElementById('name').value;
  const message = document.getElementById('message').value;
  if (name && message) {
    const entry = document.createElement('div');
    entry.innerHTML = `<strong>${name}:</strong> ${message}`;
    document.getElementById('entries').appendChild(entry);
    // Clear input fields
    document.getElementById('name').value = '';
    document.getElementById('message').value = '';
    // Storytelling
    tellStory();
  } else {
    alert('Please fill in both name and message.');
  }
}
function tellStory() {
  const entriesCount = document.getElementById('entries').childElementCount;
  if (entriesCount === 1) {
    alert("You've just added your first entry! Keep the stories coming!");
  } else if (entriesCount === 3) {
    alert("Fantastic! Three entries already! Your slam book is getting colorful!");
  } else if (entriesCount === 5) {
    alert("Wow, five entries now! Your slam book is turning into a beautiful story!");
  }
  // Add more storytelling events as needed
}